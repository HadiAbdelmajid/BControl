package server;

import action.ActionFactory;
import action.IAction;
import action.*;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

import javax.bluetooth.BluetoothStateException;
import javax.bluetooth.LocalDevice;
import javax.bluetooth.RemoteDevice;
import javax.bluetooth.UUID;
import javax.microedition.io.Connector;
import javax.microedition.io.StreamConnection;
import javax.microedition.io.StreamConnectionNotifier;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class Server {
    private final LocalDevice localDevice;
    private final String serviceName;
    private final String uuid;
    private final String url;
    private StreamConnectionNotifier streamConnectionNotifier;
    static Logger logger = Logger.getLogger(Server.class);

    public Server() throws IOException {
        String log4jConfigFile = System.getProperty("user.dir")
                + File.separator + "log4j.xml";
        DOMConfigurator.configure(log4jConfigFile);

        logger.info("Intializing server configuration...");

        localDevice = LocalDevice.getLocalDevice();
        serviceName = "BluetoothService";
        uuid = "c5168e05-f351-4360-9d55-ca691225d3fd";
        UUID BTUuid = new javax.bluetooth.UUID(this.buildUUIDForURL(uuid),false);
        url = "btspp://localhost:" + BTUuid.toString() + ";name=" + serviceName;
        logger.info("Server Configuration intialized");
        this.printConfiguration();
    }

    private void printConfiguration() {
        logger.info("Configuration:");
        logger.info("|__Device Name"  + ": " + this.localDevice.getFriendlyName());
        logger.info("|__Device Address"  + ": " + this.localDevice.getBluetoothAddress());
        logger.info("|__Service Name"  + ": "  + this.serviceName);
        logger.info("|__URL"  + ": " + this.url);
        logger.info("|__UUID"  + ": " +this.uuid);

    }




    public void start() throws IOException {
        logger.info("Starting Server...");
        streamConnectionNotifier = (StreamConnectionNotifier) Connector.open(url);
        logger.info("Server started, waiting for a connection");
        while (true) {
            StreamConnection streamConnection = streamConnectionNotifier.acceptAndOpen();
            RemoteDevice remoteDevice = RemoteDevice.getRemoteDevice(streamConnection);
            logger.info("A new client has connected: " + remoteDevice.getFriendlyName(false));
            DataInputStream in = streamConnection.openDataInputStream();
            int command = in.readInt();
            action.IAction action = ActionFactory.getAction(command);
            Thread thread = new Thread(action);
            thread.start();

        }

    }
    private String buildUUIDForURL(String uuid) {
        return uuid = uuid.replace("-","");
    }




}
