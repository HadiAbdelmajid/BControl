package action;

public enum ActionType {
    SCREENSHOT,
    MOVEMOUSE
}
