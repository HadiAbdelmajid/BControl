package action;

public class ActionFactory {
    public static IAction getAction(int actionType){
        IAction action = null;
        if (actionType == ActionType.SCREENSHOT.ordinal()){
            action = new ScreenshotAction();
        }
        else if (actionType == ActionType.MOVEMOUSE.ordinal()){
            action = new MoveMouseAction();
        }
        return action;
    }
}
