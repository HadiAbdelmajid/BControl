package action;

import java.awt.*;
import java.io.IOException;

public interface IAction extends Runnable {
    public void doAction() throws AWTException, IOException;
}
