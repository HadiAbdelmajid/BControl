package action;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import org.apache.log4j.Logger;
import server.Server;

public class ScreenshotAction implements IAction {
    static Logger logger = Logger.getLogger(Server.class);
    @Override
    public void run() {
        try {
            this.doAction();
        } catch (AWTException | IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void doAction() throws AWTException, IOException {
        logger.info("Performing Screenshot Action");
        Robot robot = new Robot();
        BufferedImage image = robot.createScreenCapture(new Rectangle(1500,920));
        File file = new File("testimage.png");
        ImageIO.write(image, "png", file);
        logger.info("Screenshot Action done");

    }
}
