package action;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import server.Server;

public class MoveMouseAction implements IAction,Runnable{
    static Logger logger = Logger.getLogger(Server.class);

    @Override
    public void doAction() throws AWTException, IOException {
        logger.info("Performing MoveMouse Action");
        Robot robot = new Robot();
        robot.mouseMove(500,500);
        logger.info("MoveMouse Action done");


    }

    @Override
    public void run() {
        try {
            this.doAction();
        } catch (AWTException | IOException e) {
            e.printStackTrace();
        }
    }
}
