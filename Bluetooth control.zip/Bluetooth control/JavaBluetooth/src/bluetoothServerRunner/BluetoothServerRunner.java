package bluetoothServerRunner;

import server.Server;

import java.awt.*;
import java.io.*;

public class BluetoothServerRunner {

    public static void main(String[] args) throws IOException, AWTException {
        Server server = new Server();
        server.start();

    }
}