package com.example.hadi.bcontrol;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Set;
public class LandingPage extends AppCompatActivity {

    private static final int Request_Enable_Bt = 0;
    private static final int Request_Discover_Bt = 1;
    TextView            BlueStatus, BluePairedStatus;
    ImageView           Blueimg;
    Button              Turn_On, Turn_Off, Discoverable, Get_Paired, Connect_pc;
    ListView            BlueScannedList;
    ArrayList<String>   stringArrayList = new ArrayList<String>();
    ArrayAdapter<String>arrayAdapter;

    public static BluetoothAdapter BlueAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_landing_page);

        BlueStatus = findViewById(R.id.statusBluetooth);
        BluePairedStatus = findViewById(R.id.Bluetoothpairedtxt);
        Blueimg = findViewById(R.id.Bluetoothimg);
        Turn_On = findViewById(R.id.Bluetoothon);
        Turn_Off = findViewById(R.id.Bluetoothoff);
        Discoverable = findViewById(R.id.Bluetoothdiscoverable);
        Get_Paired = findViewById(R.id.Bluetoothpaired);
        BlueScannedList = findViewById(R.id.scannedListView);
        Connect_pc = findViewById(R.id.Bluetoothconnecttopc);
        BlueAdapter = BluetoothAdapter.getDefaultAdapter();


        //Setting Bluetooth image based on adapetr's state
        SetimageState();


        //Turn on Bluetooth Upon clicking " Turn On" Button
        Turn_On.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!BlueAdapter.isEnabled()) {
                   ShowToast("Turning on Bluetooth...");
                    //intent to on bluetooth
                    Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                    startActivityForResult(intent, Request_Enable_Bt);
                } else {
                    ShowToast("Bluetooth is already on");
                }
            }
        });

        //Turn off Bluetooth Upon clicking " Turn Off" Button
        Turn_Off.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (BlueAdapter.isEnabled()) {
                    BlueAdapter.disable();
                    ShowToast("Turning Bluetooth Off...");
                    Blueimg.setImageResource(R.drawable.ic_action_off);
                } else {
                    ShowToast("Bluetoooth is already off");
                }
            }
        });

        //Making the device descoverable upon clicking "discoverable" button
        Discoverable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (!BlueAdapter.isDiscovering()) {
                    ShowToast("Making your device discoverable");
                    Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
                    startActivityForResult(intent, Request_Discover_Bt);
                }
            }

        });

        //Listing paired devices upon clicking "Get Paired Devices" Button
        Get_Paired.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (BlueAdapter.isEnabled()) {
                    BluePairedStatus.setText("Paired Devices");
                    BlueAdapter.startDiscovery();
                    Set<BluetoothDevice> devices = BlueAdapter.getBondedDevices();
                    for (BluetoothDevice device : devices) {
                        arrayAdapter.add("Device: " + device.getName());
                        arrayAdapter.notifyDataSetChanged();
                    }
                } else {
                    // bluetooth is off where we cant get paired devices
                    ShowToast("Turn on Bluetooth to get paired devices");
                }
            }
        });
        //Listing the Paired Devices upon the ListView
        arrayAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, stringArrayList);
        BlueScannedList.setAdapter(arrayAdapter);


        //Move to the Connection-Controll Page
        Connect_pc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    OpenIntent();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case Request_Enable_Bt:
                if (resultCode == RESULT_OK) {
                    //bluetooth is on
                    Blueimg.setImageResource(R.drawable.ic_action_on);
                    ShowToast("Bluetooth is on");
                } else {
                    //user denied to turn on bluetooth
                    ShowToast("Couldnt turn bluetooth on");
                }
                break;
        }


    }

    //toast message function
    public void ShowToast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
    //Moving to a new Intent function
    public void OpenIntent() {
        Intent intent = new Intent(this, CommandControl.class);
        startActivity(intent);
    }
    // Setting Bluetooth icon state function
    public void SetimageState() {
        if (BlueAdapter == null) {
            BlueStatus.setText("Bluetooth is not available");
        } else {
            BlueStatus.setText("Bluetooth is available");
        }
        // set image based on bluetooth status(on/off)
        if (BlueAdapter.isEnabled()) {
            Blueimg.setImageResource(R.drawable.ic_action_on);
        } else {
            Blueimg.setImageResource(R.drawable.ic_action_off);
        }
    }

}

