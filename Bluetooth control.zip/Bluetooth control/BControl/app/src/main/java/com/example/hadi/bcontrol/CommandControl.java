package com.example.hadi.bcontrol;
import android.net.MacAddress;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import java.io.IOException;
import client.ClientClass;
public class CommandControl extends LandingPage{ Button PcCapture,MouseMove,Connect;
public static String UUID;
public static String MACADDRESS;
ClientClass client = new ClientClass();

    public CommandControl() throws IOException {
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_command_control);

        PcCapture=findViewById(R.id.BlueCapture);
        MouseMove=findViewById(R.id.BlueMoveMouse);
        Connect=findViewById(R.id.BluetoothConnect);




        //Connecting to windows machine
        Connect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    client.start();
            }
        });

        //if the connection is established, take a Screenshot of the Pc Screen
        PcCapture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    if(client.btsocket.isConnected()){
                        try {
                            client.Pccapture();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    else{
                   ShowToast("Press Connect before");}

            }
        });
        //If the connection is established, Move the mouse of the Pc
        MouseMove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    if(client.btsocket.isConnected()){
                        try {
                            client.MouseMove();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    else{ ShowToast("Press the Connect button before");}


            }
        });
    }

}
