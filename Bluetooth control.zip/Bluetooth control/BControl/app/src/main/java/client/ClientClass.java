package client;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.net.MacAddress;
import android.widget.EditText;

import java.io.DataOutputStream;
import java.io.IOException;
import java.util.UUID;

import com.example.hadi.bcontrol.CommandControl;
import com.example.hadi.bcontrol.LandingPage;

public class ClientClass extends Thread {

    public  static BluetoothDevice devicez = LandingPage.BlueAdapter.getRemoteDevice("F8:E4:E3:21:D8:69");
    public static UUID uuid = UUID.fromString("c5168e05-f351-4360-9d55-ca691225d3fd");
    public static BluetoothSocket btsocket;



    static {
        try {
            btsocket = devicez.createInsecureRfcommSocketToServiceRecord(uuid);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public ClientClass() throws IOException {}
    public void run ()
    {
        try {

            btsocket.connect();
        } catch (IOException e) {
            e.printStackTrace();

        }
    }
    // Send to the server a constant that matches the Screen Capture action's enumerator Ordinal
    public void Pccapture() throws IOException {
        DataOutputStream outputstream = new DataOutputStream(btsocket.getOutputStream());
        outputstream.writeInt(0);
    }
    // Send to the server a constant that matches the Mouse Move action's enumerator Ordinal
    public void MouseMove() throws IOException {
        DataOutputStream outputstream = new DataOutputStream(btsocket.getOutputStream());
        outputstream.writeInt(1);
    }
}